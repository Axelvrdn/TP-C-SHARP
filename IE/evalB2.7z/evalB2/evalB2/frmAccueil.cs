﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace eval01B2
{
    public partial class frmAccueil : Form
    {
        public frmAccueil()
        {
            InitializeComponent();
        }

        private void calculDindemnitésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIndemnites uneFeuilleIndem = new frmIndemnites();
            MesFonctionsEtProceduresGenerales.OUVRE_UNE_MDI_FILLE(uneFeuilleIndem, this);
        }
    }
}
