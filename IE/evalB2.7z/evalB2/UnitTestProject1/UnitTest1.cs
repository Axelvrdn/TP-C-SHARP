﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using eval01B2;
using ClassLibrary1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// pour appeler la fonction : MesFPmetier.calculIndemKilo
        /// </summary>
        [TestMethod]
        public void TestMethoCalculIndemKilo()
        {
           
        }

        /// <summary>
        /// pour appeler la fonction : ClassePourTestDeDLL.donneLesPos
        /// </summary>
        [TestMethod]
        public void TestMethoDonneLesPos()
        {
            
        }
    }
}
